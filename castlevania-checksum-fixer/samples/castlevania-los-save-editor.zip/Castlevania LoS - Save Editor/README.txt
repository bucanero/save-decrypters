Castlevania: Lords Of Shadow
Xbox 360 Save Editor
Version: 0.1.0.0
Author: JizzaBeez

How to use:
1) Extract contents from gamesave.
2) Open extracted contents in editor.
3) Edit only the values you know.
4) Save the file in the editor.
5) Replace contents in gamesave.
6) Rehash and Resign the gamesave.
