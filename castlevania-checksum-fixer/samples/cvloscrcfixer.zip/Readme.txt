//------------------------------------------------------------------------------

Castlevania Lords of Shadow CRC Fixer Version: 1.0
Packed with: PECompact v3.02.2 (licensed)

//------------------------------------------------------------------------------

Build: 1.0.0.1
CRC32: FA5AEAF6
MD5  : 477A52832A4E1F455CD274377FFE6987
SHA1 : 2CB9A5F221E54C69A6F2B61F78F965E00596C527

//------------------------------------------------------------------------------

Tool Coded by: Vulnavia in DelAsmphi7
PPC-Codeanalysis by: Vulnavia
Reverse Engineering by: Vulnavia

//------------------------------------------------------------------------------

Tools used for Reverse Engineering: IDA, Hiew and Brain...

//------------------------------------------------------------------------------

Took some Hours to find, figure out and code the Tool...

//------------------------------------------------------------------------------

This Tool fixes the CRC of Castlevania Lords of Shadow Xbox Savefiles...

Yeah, thats all!

Hint: The important Stuff to edit is after Offset 0x40000.. lol

//------------------------------------------------------------------------------

~~~Disclaimer~~~

I take absolutely no Responsibility for whatever may happen if you use this Tool,
as soon as you use it, its your sole Responsibility.

This Tool is provided 'as is' with no explicit or implied warranties in respect of
its operation, including, but not limited to, correctness and fitness for purpose.

//------------------------------------------------------------------------------

Uses following Free Sources:

- ufMOD (ASM) 1.25.2a-win32 compiled with Nasm 2.10.09 Jul 22 2013

//------------------------------------------------------------------------------