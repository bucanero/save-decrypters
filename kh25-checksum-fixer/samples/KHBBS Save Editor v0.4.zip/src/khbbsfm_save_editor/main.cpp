/*
main.cpp _launcher
by Yosh
*/

#include <QApplication>
#include <QtGui>
#include "m_gui.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    /*QString locale = QLocale::system().name().section('_', 0, 0);
    QTranslator translator;
    translator.load(QString(":/all/bbsems_")+ locale);
    app.installTranslator(&translator);*/

    m_gui window;

    window.show();

    return app.exec();
}
