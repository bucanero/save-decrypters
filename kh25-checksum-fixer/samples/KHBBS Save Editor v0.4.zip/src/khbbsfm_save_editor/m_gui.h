/*
m_gui.h : gui class + all functions

by Yosh
*/

#ifndef M_GUI_H
#define M_GUI_H

#include <QWidget>
#include <QtGui>
#include <QProcess>

namespace Ui {
    class m_gui;
}

class m_gui : public QWidget
{
    Q_OBJECT

public:
    explicit m_gui(QWidget *parent = 0);
    ~m_gui();
    bool load();
    bool save();
    bool update_checksum();

private slots:
    bool analyze(QString fold, QString fnew);
    bool on_fopen_clicked();
    bool on_fsave_clicked();
    bool on_analyze_clicked();
    bool on_dlink_currentIndexChanged(int index);
    bool on_dlink_aquired_clicked();
    bool on_world_currentIndexChanged(int index);

private:
    Ui::m_gui *ui;
    QString savedata, savedatab;
    int dlinks[4][14];
    int n,bhp,thp, cur_index,old_index, curw_index,oldw_index;
    bool dummy_skip;
    char* region;
    int worlds_lvl[0x10];
};

#endif // M_GUI_H
