/*
m_gui.cpp : gui class + all functions

by Yosh
*/

#include "m_gui.h"
#include "ui_m_gui.h"

m_gui::m_gui(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::m_gui)
{
    ui->setupUi(this);
    cur_index = 0;
    old_index = cur_index;
    curw_index = 0;
    oldw_index = curw_index;
    dummy_skip = false;
    for (int i=0;i<4;i++)   for (int j=0;j<14;j++)  dlinks[i][j]=0;;
    for (int i=0;i<0x10;i++)   worlds_lvl[i]=0;
}

m_gui::~m_gui()
{
    delete ui;
}


bool m_gui::on_fopen_clicked()
{
    savedata = QFileDialog::getOpenFileName(this, tr("Select the save to edit"), QString(), tr("BIN (*.BIN);;All files (*.*)"));
    savedatab = savedata;
    QString message = "Failed to load       ";
    if (!load() && (savedata != NULL)) {
        QMessageBox::information(this, tr("Information"), "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>"+message+"</span></p></body></html>");
        savedata = "";
    }

    return true;
}


bool m_gui::on_fsave_clicked()
{
    QString message = "Saved !              ";
    if (save() && update_checksum())    QMessageBox::information(this, tr("Information"), "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>"+message+"</span></p></body></html>");
    else    message = "Failed to save       ", QMessageBox::information(this, tr("Information"), "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>"+message+"</span></p></body></html>");

    return true;
}

bool m_gui::on_dlink_aquired_clicked()
{
    if (!ui->dlink_aquired->isChecked()) {
        ui->dlink_on->setEnabled(false);
        ui->dlink_std->setEnabled(false);
        ui->dlink_1st->setEnabled(false);
        ui->dlink_m->setEnabled(false);
    }
    else {
        ui->dlink_on->setEnabled(true);
        ui->dlink_std->setEnabled(true);
        ui->dlink_1st->setEnabled(true);
        ui->dlink_m->setEnabled(true);
    }
    return true;
}


bool m_gui::on_dlink_currentIndexChanged(int index) {

    old_index = cur_index;
    cur_index = index;

    if (ui->dlink_aquired->isChecked()) dlinks[1][old_index] = 1;
    else dlinks[1][old_index] = 0;

    if (ui->dlink_on->currentIndex() == 0)  dlinks[2][old_index] = 1;
    else dlinks[2][old_index] = 0;

    if (ui->dlink_std->isChecked())    dlinks[3][old_index] = 0;
    else if (ui->dlink_1st->isChecked())    dlinks[3][old_index] = 1;
    else if (ui->dlink_m->isChecked())    dlinks[3][old_index] = 3;



    if (dlinks[1][index] == 0) {
        ui->dlink_aquired->setChecked(false);
        ui->dlink_on->setEnabled(false);
        ui->dlink_std->setEnabled(false);
        ui->dlink_1st->setEnabled(false);
        ui->dlink_m->setEnabled(false);
    }
    else if (dlinks[1][index] == 1) {
        ui->dlink_aquired->setChecked(true);
        ui->dlink_on->setEnabled(true);
        ui->dlink_std->setEnabled(true);
        ui->dlink_1st->setEnabled(true);
        ui->dlink_m->setEnabled(true);
    }

    if (dlinks[2][index] == 0)  ui->dlink_on->setCurrentIndex(1);
    else if (dlinks[2][index] == 1)  ui->dlink_on->setCurrentIndex(0);

    if (dlinks[3][index] == 0)  ui->dlink_std->setChecked(true);
    else if (dlinks[3][index] == 1)  ui->dlink_1st->setChecked(true);
    else if (dlinks[3][index] == 3)  ui->dlink_m->setChecked(true);


    return true;
}


bool m_gui::on_world_currentIndexChanged(int index) {
    int i = 0;

    oldw_index = curw_index;
    curw_index = index;

    if (oldw_index >5) {
        if (oldw_index <8)   i=1;
        else    i=2;
    }
    worlds_lvl[oldw_index+i]=ui->w_lvl->value();

    i = 0;
    if (index >5) {
        if (index <8)   i=1;
        else    i=2;
    }
    ui->w_lvl->setValue(worlds_lvl[index+i]);


    return true;
}


bool m_gui::on_analyze_clicked()
{
    int response;
    QString fnew, fold = QFileDialog::getOpenFileName(this, tr("Select the former save"), QString(), tr("BIN (*.BIN);;All files (*.*)"));
    if (fold!=NULL) fnew = QFileDialog::getOpenFileName(this, tr("Select the new save"), QString(), tr("BIN (*.BIN);;All files (*.*)"));

    QString message = "Failed to analize             ";
    if ((fold != NULL) && (fnew != NULL)) {
        response = QMessageBox::question(this, "Information", "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>    Skip dummy ? (Final Mix only)        </span></p></body></html>", QMessageBox::Yes | QMessageBox::No);
        if (response == QMessageBox::Yes)   dummy_skip = true;
        else    dummy_skip = false;
        if (!analyze(fold, fnew))    QMessageBox::information(this, tr("Information"), "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>"+message+"</span></p></body></html>");
        else  message = "analyse_log.txt created          ", QMessageBox::information(this, tr("Information"), "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0//EN' 'http://www.w3.org/TR/REC-html40/strict.dtd'><html><head><meta name='qrichtext' content='1' /><style type='text/css'>p, li { white-space: pre-wrap; }</style></head><body style=' font-family:'Segoe UI'; font-size:8.25pt; font-weight:400; font-style:normal;'><p style='-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;'></p><p style=' margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;'><span style=' font-size:9pt;'>"+message+"</span></p></body></html>");
    }

    return true;
}

#define HDATALEN 15
#define HDATA2LEN 12
int hdata[HDATALEN];
int hdata2[HDATA2LEN] = {0x0000000C,0x000059E8,0x000059EA,0x000059FE, /*step counter*/0xfe80, /*kinda money counter*/0x4f00,/*kinda enemy counters*/0x4F18,0xFDA4, 0x10090,/*?*/0x4F0C,0x59E6,0x335C};
int hdatasize[HDATALEN] = {4,4,4,4,4,1,1,1,1,1,4*2*14,1,1,1,0x10};
int hdata2size[HDATA2LEN] = {4,1,1,1,4,3,2,2,4,3,1,1};
int vhexdlink[14] = {0x7F,0x7E,0x80,0x74,0x75,0x76,0x7B,0x7A,0x79,0x7C,0x77,0x78,0x7D,0x73};

bool m_gui::load()
{
    QFile data(savedata);
    if (!data.open(QIODevice::ReadOnly))   return false;
    char buf[5];
    int val, i, j;
    int hdata_fm[HDATALEN] = {0x000059D4,0x000059D0,0x000059D8,0x0000FE88,0x00000018,0x000059DC,0x000059FA,0x11,0x5CAC,0x11,0x56C4,0x59E0,0x4D74,0x59DE,0x2815};
    int hdata_us_eur[HDATALEN] = {0x000059AC,0x000059A8,0x000059B0,0x0000FBC8,0x00000018,0x000059B4,0x000059D2,0x11,0x5C84,0x11,0x569C,0x59B8,0x4D4C,0x59B6,0x2815};
    int hdata_jap[HDATALEN] = {0x00005658,0x00005654,0x0000565C,0x0000F7B8,0x00000018,0x00005660,0x0000567E,0x11,0x58FC,0x11,0x5470,0x5664,0x4CC0,0x5662,0x2815};

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(0x00000004);
    data.read(buf,1);
    buf[0];

    switch (buf[0])
    {
        case 0x18:
            for (i=0;i<HDATALEN;i++)    hdata[i] = hdata_jap[i];
            region = "JAP";
            break;
        case 0x1C:
            for (i=0;i<HDATALEN;i++)    hdata[i] = hdata_us_eur[i];
            region = "US_EUR";
            break;
        case 0x1D:
            for (i=0;i<HDATALEN;i++)    hdata[i] = hdata_fm[i];
            region = "FM";
            break;
        default:
            region = "NONE";
            return false;
    }



    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[0]);
    data.read(buf,hdatasize[0]);
    ui->money->setValue(*((int*)buf));

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[1]);
    data.read(buf,hdatasize[1]);
    ui->exp->setValue(*((int*)buf));

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[2]);
    data.read(buf,hdatasize[2]);
    ui->medals->setValue(*((int*)buf));

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[3]);
    data.read(buf,hdatasize[3]);
    ui->emedals->setValue(*((int*)buf));

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[4]);
    data.read(buf,hdatasize[4]);
    val = *((int*)buf);
    ui->pt_hr->setValue(val/3600);
    ui->pt_mn->setValue((val/60)%60);
    ui->pt_sec->setValue(val%60);

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[5]);
    data.read(buf,hdatasize[5]);
    ui->lvl->setValue(*((int*)buf));

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[6]);
    data.read(buf,hdatasize[6]);
    for(i=0;i<0x34;i++) {
        if (buf[0] == i) {
            if (i<0x1f)   ui->keyblade->setCurrentIndex(i-1);
            else   ui->keyblade->setCurrentIndex(i-3);
        }
    }

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[8]);
    data.read(buf,hdatasize[8]);
    val = (*((int *)(buf)) - 8)/0x40;
    ui->difficulty->setCurrentIndex(val);

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[10]);
    for(i=0;i<14;i++) {
        data.read(buf,1);
        if (*((int*)buf) == vhexdlink[i]) dlinks[0][i] = 2;
        else if (*((int*)buf) == (vhexdlink[i] - 0x11))   dlinks[0][i] = 1;
        else    dlinks[0][i] = 0;

        data.read(buf,1);
        if (*((int*)buf) == 1)    dlinks[1][i] = 1;
        else    dlinks[1][i] = 0;

        data.read(buf,1);
        data.read(buf,1);
        for (j=0;j<4;j++) {
            if (*((int*)buf) == j)    dlinks[2][i] = 0, dlinks[3][i] = j;
            else if (*((int*)buf) == (j+0x80))    dlinks[2][i] = 1, dlinks[3][i] = j;
        }
        data.read(buf,4);
    }
    
	ui->dlink->setCurrentIndex(0);
	
    if (dlinks[1][0] == 0) {
        ui->dlink_aquired->setChecked(false);
        ui->dlink_on->setEnabled(false);
        ui->dlink_std->setEnabled(false);
        ui->dlink_1st->setEnabled(false);
        ui->dlink_m->setEnabled(false);
    }
    else if (dlinks[1][0] == 1) {
        ui->dlink_aquired->setChecked(true);
        ui->dlink_on->setEnabled(true);
        ui->dlink_std->setEnabled(true);
        ui->dlink_1st->setEnabled(true);
        ui->dlink_m->setEnabled(true);
    }

    if (dlinks[2][0] == 0)  ui->dlink_on->setCurrentIndex(1);
    else if (dlinks[2][0] == 1)  ui->dlink_on->setCurrentIndex(0);

    if (dlinks[3][0] == 0)  ui->dlink_std->setChecked(true);
    else if (dlinks[3][0] == 1)  ui->dlink_1st->setChecked(true);
    else if (dlinks[3][0] == 3)  ui->dlink_m->setChecked(true);

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[12]);
    data.read(buf,hdatasize[12]);
    n = *((int *)buf)%0x40;
    ui->hp->setMaximum((139*(10+n))/10);

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[11]);
    data.read(buf,hdatasize[11]);
    thp = *((int *)buf);  //realhp = hp*(10+n)/10, 0x59DE
    bhp = thp*(10+n)/10;
    ui->hp->setValue(bhp);

    for (i=0;i<5;i++)   buf[i]=0;
    data.seek(hdata[14]);
    for (i=0;i<0x10;i++) {
        data.read(buf,1);
        worlds_lvl[i]= buf[0];
    }
    ui->world->setCurrentIndex(0);
    ui->w_lvl->setValue(worlds_lvl[0]);


    data.close();

    return true;
}

bool m_gui::save()
{
    QFile data(savedata);
    if (!data.open(QIODevice::ReadWrite))   return false;
    int val = 32, i, fval;

    val = ui->money->value();
    data.seek(hdata[0]);
    data.write((char*)&val,4);

    val = ui->exp->value();
    data.seek(hdata[1]);
    data.write((char*)&val,4);

    val = ui->medals->value();
    data.seek(hdata[2]);
    data.write((char*)&val,4);

    val = ui->emedals->value();
    data.seek(hdata[3]);
    data.write((char*)&val,4);

    val = ui->pt_hr->value()*3600 + ui->pt_mn->value()*60 + ui->pt_sec->value();
    data.seek(hdata[4]);
    data.write((char*)&val,4);

    val = ui->lvl->value();
    data.seek(hdata[5]);
    data.write((char*)&val,hdatasize[5]);

    val = 0;
    val = ui->keyblade->currentIndex();
    data.seek(hdata[6]);
    for(i=0;i<0x31;i++) {
        if (val == i) {
            if (i<0x1e) {
                fval = val+1;
                data.write((char*)&(fval),1); }
            else {
                fval = val+3;
                data.write((char*)&(fval),1); }
        }
    }

    val = (ui->difficulty->currentIndex())*0x40+8;
    data.seek(hdata[8]);
    data.write((char*)&val,hdatasize[8]);

    val = ui->difficulty->currentIndex();
    data.seek(0x11);
    data.write((char*)&val,1);


    if (ui->dlink_aquired->isChecked()) dlinks[1][ui->dlink->currentIndex()] = 1;
    else dlinks[1][ui->dlink->currentIndex()] = 0;

    if (ui->dlink_on->currentIndex() == 0)  dlinks[2][ui->dlink->currentIndex()] = 1;
    else dlinks[2][ui->dlink->currentIndex()] = 0;

    if (ui->dlink_std->isChecked())    dlinks[3][ui->dlink->currentIndex()] = 0;
    else if (ui->dlink_1st->isChecked())    dlinks[3][ui->dlink->currentIndex()] = 1;
    else if (ui->dlink_m->isChecked())    dlinks[3][ui->dlink->currentIndex()] = 3;


    data.seek(hdata[10]);
    for(i=0;i<14;i++) {

        if (dlinks[1][i]) {
            if (dlinks[3][i] == 3)  val = vhexdlink[i], data.write((char*)&val,1);
            else    val = vhexdlink[i]-0x11, data.write((char*)&val,1);

            val = 1, data.write((char*)&val,1);

        data.read((char*)&val,1);

        if (dlinks[2][i])   val = dlinks[3][i]+0x80, data.write((char*)&val,1);
        else   val = dlinks[3][i], data.write((char*)&val,1);

        data.read((char*)&val,4);
        }
        else {
            val = 0;
            data.write((char*)&val,4);
            data.write((char*)&val,4);
        }

    }

    data.seek(hdata[11]);
    thp = (ui->hp->value()*10)/(10+n);
    if (((ui->hp->value()*10*10)/(10+n))>val*10)    thp++;
    data.write((char*)&thp,hdatasize[11]);
    bhp = ui->hp->value();
    data.seek(hdata[13]);
    data.write((char*)&bhp,hdatasize[13]);

    data.seek(hdata[14]);
    i=0;
    if (ui->world->currentIndex() >5) {
        if (ui->world->currentIndex() <8)   i=1;
        else    i=2;
    }
    worlds_lvl[ui->world->currentIndex()+i]=ui->w_lvl->value();

    for (i=0;i<0x10;i++) {
        data.write((char*)&worlds_lvl[i],1);
    }



    data.close();

    return true;
}


bool m_gui::update_checksum()
{
        unsigned long int old(-1), a(0), length(0), sum = 0, c = 0;

        FILE* kh = NULL;

        kh = fopen(savedata.toAscii(), "rb+");
        if (!kh) return false;

        fread(&a, 4, 2, kh);
        fread(&length, 4, 1, kh);
        fread(&a, 4, 1, kh);

        old = ftell(kh);
        fread(&a, 4, 1, kh);

        while ((ftell(kh) != old) && (c <length-4*4))   {
                c+=4;
                sum+= a;
                old = ftell(kh);
                fread(&a, 4, 1, kh);
        }

        fseek(kh, 3*4, SEEK_SET);
        fwrite(&sum, 4, 1, kh);

        fseek(kh, ((length+15)/16)*16, SEEK_SET);

        old = ftell(kh);
        fread(&a, 4, 1, kh);
        while ((ftell(kh) != old) && (a != 0x44534242))   {
                old = ftell(kh);
                fread(&a, 4, 1, kh);
        }


        if (a == 0x44534242)	{

                a = 0, length = 0, sum = 0, c = 0;
                fread(&a, 4, 1, kh);
                fread(&length, 4, 1, kh);
                fread(&a, 4, 1, kh);

                old = ftell(kh);
                fread(&a, 4, 1, kh);

                while ((ftell(kh) != old) && (c <length-4*4))   {
                        c+=4;
                        sum+= a;
                        old = ftell(kh);
                        fread(&a, 4, 1, kh);
                }

                fseek(kh, -length + 4*3, SEEK_CUR);
                fwrite(&sum, 4, 1, kh);

        }


        fclose(kh);

        return true;
}

bool m_gui::analyze(QString fold, QString fnew) {

    QString Header = "#\n# BBSFM Savedata Analysis\n# From "+fold.section('/', -1)+" to "+fnew.section('/', -1)+"\n#\n# Created: "+QDateTime::currentDateTime().toString()+"\n\n\n";
    bool ok = true;
    int old(-1), oldo(-1), c, count = 0;
    unsigned int  j, st, nd;
    unsigned char buf[4], buf2[4], cbuf, cbuf2;
    FILE *oldf = NULL, *newf = NULL, *analysis = NULL;

    oldf = fopen(fold.toAscii(), "rb");
    newf = fopen(fnew.toAscii(), "rb");
    if (!oldf || !newf) return false;

    analysis = fopen("analysis_log.txt", "w");
    if (!analysis) return false;
    fprintf(analysis,Header.toAscii());
    fprintf(analysis,"\n                   Hexadecimal                        Decimal                \n============================================================================+\n   Hex   | Previous|   New  |Difference|  Previous  |    New   | Difference |\n Address |   value |  Value |          |    value   |   Value  |            |\n=========+=========+========+==========+============+==========+============+\n");

    /*b = buf[0];
    buf[0] = buf[3];
    buf[3] = b;
    b = buf[1];
    buf[1] = buf[2];
    buf[2] = b;*/

    while (ftell(oldf) != old) {
        old = 0;
        old = ftell(oldf);
        fread(&cbuf,1,1,oldf);
        fread(&cbuf2,1,1,newf);
        if (cbuf != cbuf2) {
            if (dummy_skip) {
            for (int i=0;i<HDATALEN;i++) {
                if (old == hdata[i]) {
                    ok = false, fseek(oldf,hdatasize[i],SEEK_CUR), fseek(newf,hdatasize[i],SEEK_CUR);
                    break;
                }
            }
            for (int i=0;i<HDATA2LEN;i++) {
                if (old == hdata2[i]) {
                    ok = false, fseek(oldf,hdata2size[i],SEEK_CUR), fseek(newf,hdata2size[i],SEEK_CUR);
                    break;
                }
            }
            }

            if (ok) {
            c = 0;
            st = 0;
            nd = 0;
            oldo = old;
            count++;
            fprintf(analysis," %8X|",oldo);
            do {
                buf[c]= cbuf, buf2[c]= cbuf2;
                c++;
                if (c <(4-(oldo%4))) {
                    old = 0;
                    old = ftell(oldf);
                    fread(&cbuf,1,1,oldf);
                    fread(&cbuf2,1,1,newf); }
            } while (((cbuf != cbuf2) || ((cbuf != 0) || (cbuf2 != 0))) && (ftell(oldf) != old) && (c<4-(oldo%4)));

            if (c == 4) {
                nd = buf2[3]*0x1000000+buf2[2]*0x10000+buf2[1]*0x100+buf2[0];
                st = buf[3]*0x1000000+buf[2]*0x10000+buf[1]*0x100+buf[0];
            }
            else if (c == 3) {
                nd = buf2[2]*0x10000+buf2[1]*0x100+buf2[0];
                st = buf[2]*0x10000+buf[1]*0x100+buf[0]; }
            else if (c == 2) {
                nd = buf2[1]*0x100+buf2[0];
                st = buf[1]*0x100+buf[0]; }
            else if (c == 1) {
                nd = buf2[0];
                st = buf[0]; }
			
			if (st>nd)	j = st - nd;
			else	j = nd - st;
            

            if (st>nd)    fprintf(analysis," %8X|%8X| -%8X|  %10u|%10u| -%10u|\n",st,nd,j,st,nd,j);
            else    fprintf(analysis," %8X|%8X| +%8X|  %10u|%10u| +%10u|\n",st,nd,j,st,nd,j);
            }
            ok = true;
        }
    }
    fprintf(analysis,"=========+=========+========+==========+============+==========+============+\n\n\nDifferences : %d\n\n\n\n",count);

    fclose(oldf);
    fclose(newf);
    fclose(analysis);

    return true;
}
