#include <iostream>
#include <fstream>

using namespace std;


int main(int argc, char **argv)
{
	unsigned long int old(-1), a(0), length(0), sum = 0, c = 0;

	FILE* kh = NULL;

	if (argc == 2) kh = fopen(argv[1], "rb+");
	else    return 1;

	fread(&a, 4, 2, kh);
	fread(&length, 4, 1, kh);
	fread(&a, 4, 1, kh);

	old = ftell(kh);
	fread(&a, 4, 1, kh);

	while ((ftell(kh) != old) && (c <length-4*4))   {
		c+=4;
		sum+= a;
		old = ftell(kh);
		fread(&a, 4, 1, kh);
	}

	fseek(kh, 3*4, SEEK_SET);
	fwrite(&sum, 4, 1, kh);
	
	cout << hex << sum << endl;


	fseek(kh, ((length+15)/16)*16, SEEK_SET);

	old = ftell(kh);
	fread(&a, 4, 1, kh);
	while ((ftell(kh) != old) && (a != 0x44534242))   {
		old = ftell(kh);
		fread(&a, 4, 1, kh);
	}


	if (a == 0x44534242)	{

		a = 0, length = 0, sum = 0, c = 0;
		fread(&a, 4, 1, kh);
		fread(&length, 4, 1, kh);
		fread(&a, 4, 1, kh);

		old = ftell(kh);
		fread(&a, 4, 1, kh);

		while ((ftell(kh) != old) && (c <length-4*4))   {
			c+=4;
			sum+= a;
			old = ftell(kh);
			fread(&a, 4, 1, kh);
		}

		fseek(kh, -length + 4*3, SEEK_CUR);
		fwrite(&sum, 4, 1, kh);
		
		cout << hex << sum << endl;
	}


	fclose(kh);

	return 0;
}
