Kingdom Hearts Birth by Sleep - Save Edit Enabler
by Yosh, 22.07.11

Purpose :
This program enables to freely hex edit the save data without getting a "corrupted save" error

How to use :
To fix this error after editing your save, just Drag'n Drop it on this "kh.exe" program and it'll be done automatically ! enjoy
